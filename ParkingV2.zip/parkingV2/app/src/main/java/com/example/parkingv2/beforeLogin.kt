package com.example.parkingv2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.WindowManager
import kotlinx.android.synthetic.main.activity_before_login.*

class beforeLogin : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar()?.hide(); // hide the title bar
   /*     this.getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen*/
        setContentView(R.layout.activity_before_login)
    }

    fun chefPark(view: View) {
        var ToPhone = Intent(this,LoginPhone::class.java)
        startActivity(ToPhone)
    }
    fun cadreLogin(view: View) {
        var ToLogin = Intent(this,LoginActivity::class.java)
        startActivity(ToLogin)
    }

    fun SignUpBu(view: View) {
        var ToSignUp = Intent(this,SignupActivity::class.java)
        startActivity(ToSignUp)
    }
}
