package com.example.parkingv2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_login_phone.*


class LoginPhone : AppCompatActivity() {
    private var editTextMobile: EditText? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_phone)
        editTextMobile = findViewById(R.id.edMobile)
        findViewById<View>(R.id.buttonContinue).setOnClickListener(View.OnClickListener {
            val mobile = edMobile.getText().toString().trim { it <= ' ' }
            if (mobile.isEmpty() || mobile.length < 10) {
                edMobile.setError("Entez votre numero")
                edMobile.requestFocus()
                return@OnClickListener
            }
            val intent = Intent(this@LoginPhone, VerifyPhoneActivity::class.java)
            intent.putExtra("mobile", mobile)
            startActivity(intent)
        })
    }
}