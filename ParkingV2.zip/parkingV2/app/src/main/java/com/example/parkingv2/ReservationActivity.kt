package com.example.parkingv2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Window
import android.widget.Button
import com.google.firebase.auth.FirebaseAuth
import kotlin.math.sign

class ReservationActivity : AppCompatActivity() {
    private var signOut: Button? = null
    private var auth: FirebaseAuth? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar()?.hide(); // hide the title bar
        setContentView(R.layout.activity_reservation)
        auth = FirebaseAuth.getInstance()
        signOut = findViewById<Button>(R.id.sign_out)
        signOut?.setOnClickListener {
                FirebaseAuth.AuthStateListener { firebaseAuth ->
                    val user = firebaseAuth.currentUser
                    if (user == null) {
                        signOut()
                        startActivity(Intent(this@ReservationActivity, LoginActivity::class.java))
                        finish()
                    }

                }

        }
    }

    private fun signOut() {
        // [START auth_sign_out]
        auth?.signOut()
        startActivity(Intent(this@ReservationActivity, LoginActivity::class.java))
        finish()
        // [END auth_sign_out]
    }
}
